/*
        image_editor.cpp
        
        Method implementations for the image_editor class.

        author: C. Painter-Wakefield

        last modified: 1/15/2018
*/

#include <utility>

#include "image_editor.h"

using namespace std;

bool image_editor::load(istream& in) {
    // test magic string
    string magic;
    in >> magic;
    if (magic != "P3") return false;

    // TODO: get columns, rows, ensure valid

    // TODO: get and discard color depth

    // TODO: initialize your image storage data structure

    // TODO: get image data from input stream into your data structure

    return true;
}

void image_editor::save(ostream& out) {
    // TODO: output valid PPM file format data to the
    // output stream out
}

int image_editor::get_rows() {
    // TODO: return the correct # of rows
    return 300;
}

int image_editor::get_columns() {
    // TODO: return the correct # of columns
    return 500;
}

int image_editor::get_red(int row, int col) {
    // TODO: return the actual pixel red value
    return 255 - (row * col) % 256;
}

int image_editor::get_green(int row, int col) {
    // TODO: return the actual pixel green value
    return 255 - (row * col) % 256;
}

int image_editor::get_blue(int row, int col) {
    // TODO: return the actual pixel blue value
    return 255;
}

void image_editor::apply_effect(int action_index) {
    enum action a = (enum action)action_index;

    // TODO: fill out this method
    if (a == GRAYSCALE) {
        // call a method that applies the grayscale
        // effect to the image in your data structure
    } else if (a == NEGATE_RED) {
        // etc.
    }
}

// TODO: add effect methods below here


